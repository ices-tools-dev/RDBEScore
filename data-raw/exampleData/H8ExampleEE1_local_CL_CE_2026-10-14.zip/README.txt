H8ExampleEE1 local CL and CE tables, retained on 2026-10-14.
Source: H8_2025_02_11.rds, prepared during issue #279.
Storage types corrected. Scheme EST_OnShoreCommercialPelagic and flag country ZW.
Measurements and vessel counts retained. Vessel memberships remain missing.
These tables were not uploaded or validated by RDBES.
CS export: 2101145e-b681-4ce7-8970-7eb48e752573.
VD export: 138227bc-430e-49c5-829e-23d0021e0580.
SL export: 5c7b92f0-055d-4490-af4b-68bf517fc5fd.
Production RDBES, ZW, 2022, institution 714.
